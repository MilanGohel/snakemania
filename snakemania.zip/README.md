# SnakeMania
## Video Demo:  https://youtu.be/zHdnveGyDCE
## Description:

### **Languages used**
    A classic snake game built with HTML, CSS, and JavaScript.

### **How to Play**
    Use arrow keys to control the snake's direction
    Eat the food to grow the snake
    Don't hit the walls or the snake's body


### **How to run the project**
    Clone the repository
    Open the index.html file in your browser
    
### **Requirements**
    A modern browser that supports HTML5 and JavaScript
    Contributing
    Feel free to contribute to the project by submitting a pull request.
